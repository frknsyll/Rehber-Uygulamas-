﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Rehber
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(textBox2.PasswordChar.ToString()=="*")
            {
                textBox2.PasswordChar = char.Parse("\0");
                button3.Text = "Gizle";
            }

            else
            {
                textBox2.PasswordChar=char.Parse("*");
                button3.Text="Göster";
            }

        }

        
        private void eventLog1_EntryWritten(object sender, System.Diagnostics.EntryWrittenEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string cepno = maskedTextBox1.Text;
            string sifre = textBox2.Text;

            if (string.IsNullOrEmpty(cepno) || string.IsNullOrEmpty(sifre))
            {
                MessageBox.Show("Hatalı Cep No veya Şifre");
                return;

            }
            else
            {
                this.Hide();
                Form2 form2 = new Form2();
                form2.Show();
            }
        }
    }
}
