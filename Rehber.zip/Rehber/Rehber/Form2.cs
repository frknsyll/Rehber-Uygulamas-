﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Rehber
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

       



        private void button1_Click(object sender, EventArgs e)
        {
              
            
            this.Hide();
            Form3 form3 = new Form3();
            form3.Show();
        
        }

        private void Form2_Load(object sender, EventArgs e)
        {

           

            listView1.View = View.Details;
            listView1.GridLines = true;
            listView1.FullRowSelect = true;

            listView1.Columns.Add("İsim", 150);
            listView1.Columns.Add("Soyisim", 150);
            listView1.Columns.Add("CepNo", 150);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();

            Form1 form1 = new Form1();
            form1.Show();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public void AddToListView(string isim , string soyisim, string cepno)
        {
            ListViewItem item = new ListViewItem(isim);
            item.SubItems.Add(soyisim);
            item.SubItems.Add(cepno);
            listView1.Items.Add(item);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0) 
            {
                listView1.Items.Remove(listView1.SelectedItems[0]);
            }
            else
            {
                MessageBox.Show("Silinecek bir öğe seçin");
            }
        }


       
    }
}
