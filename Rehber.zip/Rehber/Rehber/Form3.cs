﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Rehber
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {








            Form2 form2 = (Form2)Application.OpenForms["form2"];
            if (form2 != null)
            {
                form2.AddToListView(textBox1.Text, textBox2.Text, maskedTextBox1.Text);

            }




            string isim = textBox1.Text;
            string soyisim = textBox2.Text;
            string cepno = maskedTextBox1.Text;

            if (string.IsNullOrEmpty(isim) || string.IsNullOrEmpty(soyisim) || string.IsNullOrEmpty(cepno))
            {
                MessageBox.Show("hatalı bilgiler");
                return;
            }

            else
            {
                this.Close();
                form2.Show();
            }


        }
    }
}
